# JAR'I GITHUB ÜZERİNDEN OTOMATİK DERLETME (Maven kurmana gerek yok)

Bu yöntemde sen hiçbir şey kurmuyorsun. Kodu GitHub'a yüklüyorsun, GitHub'ın
kendi sunucusu Java ve Maven'i kurup jar'ı derliyor, sana indirilebilir bir
dosya olarak veriyor. Toplam 5 adım, ~5 dakika.

---

## 1. GitHub hesabı oluştur

https://github.com/signup adresine git, e-posta ile ücretsiz hesap aç.
(Zaten hesabın varsa bu adımı atla.)

## 2. Yeni bir "repository" (depo) oluştur

1. Giriş yaptıktan sonra sağ üstte **+** işaretine bas → **"New repository"**
2. **Repository name**: `mybkn-plugin` yaz
3. **Public** seçili kalsın (Private de olur, farketmez)
4. Diğer kutucuklara dokunma, direkt **"Create repository"** butonuna bas

## 3. Dosyaları GitHub'a yükle

1. Az önce açılan boş depo sayfasında **"uploading an existing file"**
   yazısına (mavi link) tıkla
2. Bilgisayarındaki `MybknCore` klasörünün **İÇİNDEKİ HER ŞEYİ** seç
   (klasörün kendisini değil, içindeki `src` klasörü, `pom.xml`, `.github`
   klasörü vs. — hepsini birden sürükle bırak)

   ⚠️ Önemli: `.github` klasörü gizli görünebilir, dosya gezgininde
   "Gizli öğeler" gösterimini aç ki bu klasörü de sürükleyebilesin.
   (Dosya Gezgini → Görünüm → Gizli öğeler kutusunu işaretle)

3. Sayfanın altında **"Commit changes"** butonuna bas

## 4. Otomatik derlemeyi başlat

1. Depo sayfasının üst menüsünde **"Actions"** sekmesine tıkla
2. "Build MybknCore Plugin" adında bir işlem görünecek, üzerine tıkla
3. Eğer otomatik başlamadıysa sağda **"Run workflow"** butonuna bas
4. Sarı nokta (çalışıyor) yeşil tike (✓ tamamlandı) dönene kadar bekle
   (~1-2 dakika sürer)

## 5. Jar'ı indir

1. Yeşil tik çıkan işlemin üzerine tıkla
2. Sayfanın altında **"Artifacts"** bölümünde **"MybknCore-jar"** yazısını
   göreceksin — üzerine tıkla, otomatik bir zip inecek
3. İnen zip'i aç, içinde **`MybknCore.jar`** dosyası var
4. Bu jar'ı her sunucunun (lobby, survival1, vb.) `plugins/` klasörüne kopyala

---

## Sorun olursa

- **Actions sekmesinde hiçbir şey görünmüyor** → `.github/workflows/build.yml`
  dosyası yüklenmemiş olabilir, gizli klasör gösterimini açtığından emin ol,
  3. adımı tekrarla.
- **Kırmızı çarpı (✗) çıktı, derleme başarısız** → işlemin üzerine tıkla,
  kırmızı satırı bul, ekran görüntüsü at, birlikte çözeriz.
- **"Artifacts" bölümü boş/yok** → derleme henüz bitmemiş olabilir, sayfayı
  yenile.

Jar'ı plugins klasörüne koyduktan sonra sunucuyu yeniden başlat — bu sefer
MYBKN sistemi (kayıt/giriş, market, rank, menü) gelecek.
