# MYBKN AĞI — 1000 Kişilik Sunucu Kurulum Rehberi

## ÖNCE GERÇEĞİ KONUŞALIM

Tek bir Paper/Spigot sunucusu, tek bir dünyada, **gerçekten aktif 1000 oyuncuyu
kaldıramaz.** Bu RAM meselesi değil — sunucu yazılımının (tick döngüsü tek
thread'de çalışır) mimari sınırı. 50 GB RAM verseniz de sonuç değişmez.

Büyük ağlar (Hypixel, Mineplex vb.) bunu şöyle çözer:

```
                     OYUNCULAR (1000 kişi, hepsi aynı IP'ye bağlanır)
                              │
                              ▼
                    ┌──────────────────┐
                    │  VELOCITY PROXY  │   ← tek giriş noktası
                    │   (port 25565)   │
                    └──────────────────┘
                              │
        ┌──────────┬─────────┼─────────┬──────────┐
        ▼          ▼         ▼         ▼          ▼
     Lobby-1   Survival-1 Survival-2 Survival-3  Lobby-2
     (~150)     (~150)     (~150)     (~150)     (~150)
```

Oyuncu tek bir IP/port'a bağlanır (örnek: `play.mybkn.com`), Velocity onu
arka plandaki sunuculardan birine yönlendirir. Oyuncu için tek bir ağ gibi
görünür ama her alt sunucu kendi 100-200 kişisini taşır — gerçekçi limit.

**16-32 GB RAM'inle bu mimariyi rahatça kurabilirsin.** Örnek dağılım (24GB):

| Sunucu      | RAM   | Oyuncu kapasitesi |
|-------------|-------|--------------------|
| Velocity    | 2 GB  | -                   |
| Lobby       | 2 GB  | ~100                |
| Survival-1  | 5 GB  | ~150                |
| Survival-2  | 5 GB  | ~150                |
| Survival-3  | 5 GB  | ~150                |
| (yedek)     | 5 GB  | büyüme için         |

Toplamda gerçekçi olarak **500-700 eşzamanlı oyuncu** civarı bekleyebilirsin.
"1000" rakamı pazarlama dilinde sık geçer ama gerçek eşzamanlı kapasite çok
daha düşüktür — bunu bilerek ilerlemen önemli.

---

## 1. KLASÖR YAPISI

```
MybknNetwork/
├── velocity/
│   ├── velocity.jar
│   └── velocity.toml
├── lobby/
│   ├── paper.jar
│   ├── start.bat
│   └── plugins/MybknCore.jar
├── survival1/
│   ├── paper.jar
│   ├── start.bat
│   └── plugins/MybknCore.jar
└── survival2/
    └── ... (ayni yapı)
```

Her sunucu **kendi klasöründe**, kendi `paper.jar`'ı ile çalışır. MybknCore
eklentisi her birine ayrı ayrı atılır ama hepsi **aynı MySQL veritabanına**
bağlanır — böylece bir survival'dan lobiye geçen oyuncunun bakiyesi kaybolmaz.

---

## 2. VELOCITY PROXY KURULUMU

1. https://papermc.io/downloads/velocity adresinden son sürümü indir,
   `velocity/velocity.jar` olarak kaydet.
2. Java 21 ile çalıştır:
   ```
   java -jar velocity.jar
   ```
3. İlk açılışta `velocity.toml` oluşur. Şunları düzenle:

```toml
bind = "0.0.0.0:25565"
motd = "<#55FFFF>MYBKN AĞI"
player-info-forwarding-mode = "modern"

[servers]
lobby = "127.0.0.1:25566"
survival1 = "127.0.0.1:25567"
survival2 = "127.0.0.1:25568"

try = ["lobby"]

[forced-hosts]
# bos birakabilirsin
```

4. **ÖNEMLİ — modern forwarding için her alt sunucuda da ayar gerekiyor**
   (aşağıda 4. bölümde).

5. Velocity'yi her zaman bu klasörden başlat:
   ```
   java -Xms2G -Xmx2G -jar velocity.jar
   ```

---

## 3. HER ALT SUNUCU İÇİN PAPER KURULUMU

Her alt sunucu klasörü (`lobby/`, `survival1/`, vb.) için aynı adımları
tekrarla:

1. https://papermc.io/downloads adresinden Paper `.jar` indir.
2. `start.bat` oluştur (RAM'i sunucunun önemine göre ayarla):

```bat
@echo off
cd /d "%~dp0"
java -Xms2G -Xmx5G -jar paper.jar nogui
pause
```

3. `eula.txt` içinde `eula=true` yap.
4. Her sunucunun **farklı bir portta** çalıştığından emin ol
   (`server.properties` içinde `server-port`):
   - lobby → 25566
   - survival1 → 25567
   - survival2 → 25568

---

## 4. VELOCITY MODERN FORWARDING (ZORUNLU AYAR)

Velocity arkasındaki her Paper sunucusunda, `config/paper-global.yml`
içinde:

```yaml
proxies:
  velocity:
    enabled: true
    online-mode: true
    secret: "BURAYA_VELOCITY_FORWARDING_SECRET_DOSYASINDAKI_KODU_YAPISTIR"
```

`forwarding.secret` dosyası Velocity klasöründe otomatik oluşur — içindeki
kodu kopyala, her alt sunucunun `paper-global.yml`'ine aynen yapıştır.

Ayrıca her alt sunucunun `server.properties` dosyasında:
```
online-mode=false
```
(Çünkü kimlik doğrulamayı artık Velocity, modern forwarding ile yapıyor.)

---

## 5. MYBKNCORE EKLENTİSİNİ DERLEME

Bu sohbette sana **eksiksiz Java kaynak kodu** verildi (Maven projesi).
Sandbox ortamımda internet erişimi kapalı olduğu için jar'ı burada
derleyemedim — sen kendi bilgisayarında şu adımları izle:

1. [Maven](https://maven.apache.org/download.cgi) ve Java 21 JDK kurulu olsun.
2. Proje klasörüne gir (`MybknCore/` — `pom.xml`'in olduğu yer).
3. Terminalde:
   ```
   mvn clean package
   ```
4. `target/MybknCore.jar` oluşacak.
5. Bu jar'ı **her alt sunucunun** `plugins/` klasörüne kopyala (lobby,
   survival1, survival2 — hepsine aynı jar).

Maven kurulu değilse en kolay yol: VS Code'a **"Extension Pack for Java"**
eklentisini kur, içinde Maven entegre gelir, `pom.xml`'e sağ tıklayıp
"Run Maven Build" diyebilirsin.

---

## 6. MYSQL VERİTABANI KURULUMU (ZORUNLU)

Tüm sunucular aynı veriyi paylaşsın diye **tek bir MySQL** sunucusu gerekiyor.

1. [XAMPP](https://www.apachefriends.org) veya [MySQL Installer](https://dev.mysql.com/downloads/installer/) indir, kur.
2. MySQL çalışırken bir veritabanı oluştur:
   ```sql
   CREATE DATABASE mybkn;
   CREATE USER 'mybkn_user'@'localhost' IDENTIFIED BY 'GUCLU_BIR_SIFRE';
   GRANT ALL PRIVILEGES ON mybkn.* TO 'mybkn_user'@'localhost';
   FLUSH PRIVILEGES;
   ```
3. Her alt sunucunun `plugins/MybknCore/config.yml` dosyasında:
   ```yaml
   database:
     host: 127.0.0.1
     port: 3306
     database: mybkn
     username: mybkn_user
     password: "GUCLU_BIR_SIFRE"
   ```
   (Tüm sunucularda **aynı** bilgiler — host'u gerçek MySQL sunucusunun
   IP'sine göre ayarla, hepsi aynı makinedeyse `127.0.0.1` kalabilir.)

---

## 7. BAŞLATMA SIRASI

Her zaman şu sırayla başlat:

1. MySQL (servis olarak otomatik açılır genelde)
2. Her Paper alt sunucusu (`lobby`, `survival1`, `survival2`...)
3. Velocity (en son — alt sunucular zaten ayakta olmalı)

---

## 8. SORUN OLURSA

- **"Plugin yuklenemedi"** → config.yml'deki MySQL bilgilerini kontrol et,
  MySQL servisinin çalıştığından emin ol.
- **Oyuncu proxy'ye bağlanamıyor** → 25565 portunun modeminde/router'ında
  açık olduğundan emin ol (port forwarding).
- **"Bu sunucudan IP banlandı" gibi bir hata** → modern forwarding secret
  uyuşmuyor, 4. adımı tekrar kontrol et.

Herhangi bir adımda hata alırsan, tam hata mesajını ve ekran görüntüsünü
gönder — birlikte çözeriz.
