# Yüksek Oyuncu Sayısı için Performans Ayarları

Bu ayarları **her alt sunucunun** (lobby, survival1, survival2...) ilgili
config dosyalarına uygula. Sunucuyu bir kere çalıştırıp kapattıktan sonra
bu dosyalar otomatik oluşur, sonra düzenle.

## server.properties

```properties
online-mode=false
view-distance=6
simulation-distance=5
max-players=200
network-compression-threshold=256
sync-chunk-writes=false
entity-broadcast-range-percentage=60
```

`view-distance` ve `simulation-distance` en büyük performans kazancını
verir. 1000 kişi senaryosunda 10+ değerleri sunucuyu çökertir; 5-6 idealdir.

## config/paper-world-defaults.yml (önemli kısımlar)

```yaml
chunks:
  max-auto-save-chunks-per-tick: 8
  entity-per-chunk-save-limit:
    experience-orb: 16
    item: 32

entities:
  spawning:
    despawn-ranges:
      animal:
        soft: 24
        hard: 64
      monster:
        soft: 24
        hard: 64
  entities-target-events:
    treasure-maps: false

tick-rates:
  mob-spawner: 4
  villager-market: 5

hopper:
  cooldown-when-full: true
```

## config/paper-global.yml (önemli kısımlar)

```yaml
async-chunks:
  enabled: true

watchdog:
  early-warning-every: 5000
  early-warning-delay: 10000
```

## JVM başlatma parametreleri (Aikar's flags)

Sunucu camiasında "Aikar's flags" diye bilinen, GC duraklamalarını
ciddi şekilde azaltan başlatma parametreleri. `start.bat` içine
`-Xms`/`-Xmx`'ten sonra ekle:

```bat
java -Xms5G -Xmx5G ^
  -XX:+UseG1GC ^
  -XX:+ParallelRefProcEnabled ^
  -XX:MaxGCPauseMillis=200 ^
  -XX:+UnlockExperimentalVMOptions ^
  -XX:+DisableExplicitGC ^
  -XX:+AlwaysPreTouch ^
  -XX:G1NewSizePercent=30 ^
  -XX:G1MaxNewSizePercent=40 ^
  -XX:G1HeapRegionSize=8M ^
  -XX:G1ReservePercent=20 ^
  -XX:G1HeapWastePercent=5 ^
  -XX:G1MixedGCCountTarget=4 ^
  -XX:InitiatingHeapOccupancyPercent=15 ^
  -XX:G1MixedGCLiveThresholdPercent=90 ^
  -XX:G1RSetUpdatingPauseTimePercent=5 ^
  -XX:SurvivorRatio=32 ^
  -XX:+PerfDisableSharedMem ^
  -XX:MaxTenuringThreshold=1 ^
  -Dusing.aikars.flags=https://mcflags.emc.gs ^
  -Daikars.new.flags=true ^
  -jar paper.jar nogui
pause
```

`^` Windows'ta satır devam karakteridir — `.bat` dosyasında bu şekilde
çok satıra bölünebilir.

## Önerilen eklentiler (opsiyonel ama 1000 kişilik ağda çok faydalı)

- **Spark** — gerçek zamanlı performans profil aracı (`/spark profiler`),
  hangi plugin/sistem lag yapıyor görmek için.
- **ViaVersion** — farklı Minecraft sürümlerinden bağlanmaya izin verir,
  oyuncu havuzunu büyütür.
- **LuckPerms** — yetki yönetimi; OP sistemini büyük ağlarda LuckPerms'e
  taşımak çok daha güvenli ve esnektir.
