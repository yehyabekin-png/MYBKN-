package com.mybkn.core;

import com.mybkn.core.commands.BalCommand;
import com.mybkn.core.commands.EcoCommand;
import com.mybkn.core.commands.LoginCommand;
import com.mybkn.core.commands.MarketCommand;
import com.mybkn.core.commands.MenuCommand;
import com.mybkn.core.commands.PayCommand;
import com.mybkn.core.commands.RankCommand;
import com.mybkn.core.commands.RankupCommand;
import com.mybkn.core.commands.RegisterCommand;
import com.mybkn.core.commands.SetrankCommand;
import com.mybkn.core.data.AccountManager;
import com.mybkn.core.data.DatabaseManager;
import com.mybkn.core.gui.MainMenuGUIListener;
import com.mybkn.core.gui.MarketGUIListener;
import com.mybkn.core.listeners.AuthGateListener;
import com.mybkn.core.listeners.PlayerConnectionListener;
import com.mybkn.core.listeners.RankChatListener;
import com.mybkn.core.listeners.RankMiningListener;
import com.mybkn.core.market.MarketManager;
import com.mybkn.core.rank.RankManager;
import org.bukkit.plugin.java.JavaPlugin;

public class MybknCore extends JavaPlugin {

    private static MybknCore instance;

    private DatabaseManager databaseManager;
    private AccountManager accountManager;
    private MarketManager marketManager;
    private RankManager rankManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.databaseManager = new DatabaseManager(this);
        boolean connected = databaseManager.connect();
        if (!connected) {
            getLogger().severe("[MybknCore] Veritabanina baglanilamadigi icin plugin devre disi birakiliyor.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        this.accountManager = new AccountManager(this, databaseManager);
        this.marketManager = new MarketManager(this);
        this.marketManager.loadFromConfig();

        this.rankManager = new RankManager(this);
        try {
            this.rankManager.createTables();
        } catch (Exception e) {
            getLogger().severe("[MybknCore] Rank tablolari olusturulamadi: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        registerCommands();
        registerListeners();

        getLogger().info("[MybknCore] Sistem aktif! " + marketManager.getItemCount() + " market urunu yuklendi.");
    }

    @Override
    public void onDisable() {
        if (databaseManager != null) {
            databaseManager.close();
        }
    }

    private void registerCommands() {
        getCommand("register").setExecutor(new RegisterCommand(this));
        getCommand("login").setExecutor(new LoginCommand(this));
        getCommand("bal").setExecutor(new BalCommand(this));
        getCommand("pay").setExecutor(new PayCommand(this));
        getCommand("eco").setExecutor(new EcoCommand(this));
        getCommand("market").setExecutor(new MarketCommand(this));
        getCommand("mybkn").setExecutor(new MenuCommand(this));
        getCommand("rankup").setExecutor(new RankupCommand(this));
        getCommand("rank").setExecutor(new RankCommand(this));
        getCommand("setrank").setExecutor(new SetrankCommand(this));
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new PlayerConnectionListener(this), this);
        getServer().getPluginManager().registerEvents(new AuthGateListener(this), this);
        getServer().getPluginManager().registerEvents(new MarketGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new MainMenuGUIListener(this), this);
        getServer().getPluginManager().registerEvents(new RankMiningListener(this), this);
        getServer().getPluginManager().registerEvents(new RankChatListener(this), this);
    }

    public static MybknCore get() {
        return instance;
    }

    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    public AccountManager getAccountManager() {
        return accountManager;
    }

    public MarketManager getMarketManager() {
        return marketManager;
    }

    public RankManager getRankManager() {
        return rankManager;
    }
}
