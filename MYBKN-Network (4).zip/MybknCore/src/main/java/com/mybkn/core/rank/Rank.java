package com.mybkn.core.rank;

import org.bukkit.Material;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * All ranks in the network, in order.
 *
 * Two families:
 *  - PROGRESSION ranks (OYUNCU..KRAL): earned via /rankup by completing
 *    block-mining tasks. Each one has a "next" rank and a requirement.
 *  - SPECIAL ranks (INSAN..KURUCU): can ONLY be granted by an admin via
 *    /setrank. They sit "above" KRAL and are not reachable through
 *    normal rankup, no matter how many tasks are completed.
 *
 * KURUCU is hardcoded to a single username ("ekmeko") - see RankManager.
 */
public enum Rank {

    // ---------------- progression ranks (earned via /rankup) ----------------
    OYUNCU(0, "§7Oyuncu", "§7", false, null, 0, 0.0, null,
            Map.of()),

    CIRAK(1, "§fÇırak", "§f", false, OYUNCU, 0, 0.0, null,
            Map.of(Material.STONE, 100)),

    SAVASCI(2, "§a§lSavaşçı", "§a", false, CIRAK, 250, 250.0, Material.IRON_SWORD,
            Map.of(Material.IRON_ORE, 150, Material.COAL_ORE, 100)),

    SOVALYE(3, "§9§lŞövalye", "§9", false, SAVASCI, 750, 750.0, Material.IRON_CHESTPLATE,
            Map.of(Material.GOLD_ORE, 100, Material.IRON_ORE, 200)),

    LORD(4, "§5§lLord", "§5", false, SOVALYE, 2000, 2000.0, Material.DIAMOND_SWORD,
            Map.of(Material.DIAMOND_ORE, 64, Material.GOLD_ORE, 150)),

    KRAL(5, "§6§l§nKral", "§6§l", false, LORD, 5000, 5000.0, Material.NETHERITE_INGOT,
            Map.of(Material.DIAMOND_ORE, 128, Material.ANCIENT_DEBRIS, 16)),

    // ---------------- special ranks (admin-only, via /setrank) ----------------
    INSAN(6, "§b§lİnsan", "§b§l", true, KRAL, 0, 0.0, null, Map.of()),

    GUCLU(7, "§d§l§oGüçlü", "§d§l", true, INSAN, 0, 0.0, null, Map.of()),

    YUCE(8, "§c§l§nYüce", "§c§l", true, GUCLU, 0, 0.0, null, Map.of()),

    YOUTUBER(9, "§4§l▶ §f§lYoutuber", "§4§l", true, YUCE, 0, 0.0, null, Map.of()),

    KURUCU(10, "§0§l☠ §4§l§nKurucu", "§4§l§n", true, YOUTUBER, 0, 0.0, null, Map.of());

    private final int level;
    private final String displayName;
    private final String chatColor;
    private final boolean special;
    private final Rank previous;
    private final double moneyReward;
    private final double rankupMoneyCost;
    private final Material itemReward;
    private final Map<Material, Integer> requirements;

    Rank(int level, String displayName, String chatColor, boolean special, Rank previous,
         double rankupMoneyCost, double moneyReward, Material itemReward,
         Map<Material, Integer> requirements) {
        this.level = level;
        this.displayName = displayName;
        this.chatColor = chatColor;
        this.special = special;
        this.previous = previous;
        this.rankupMoneyCost = rankupMoneyCost;
        this.moneyReward = moneyReward;
        this.itemReward = itemReward;
        this.requirements = requirements;
    }

    public int getLevel() {
        return level;
    }

    /** Full colored name shown in chat, tab list, etc. */
    public String getDisplayName() {
        return displayName;
    }

    public String getChatColor() {
        return chatColor;
    }

    /** True if this rank can ONLY be given by an admin (/setrank), never via /rankup. */
    public boolean isSpecial() {
        return special;
    }

    public Rank getPrevious() {
        return previous;
    }

    /** Extra money the player must pay (on top of finishing tasks) to rank up into this rank. */
    public double getRankupMoneyCost() {
        return rankupMoneyCost;
    }

    /** Money given to the player as a reward when they reach this rank. */
    public double getMoneyReward() {
        return moneyReward;
    }

    public Material getItemReward() {
        return itemReward;
    }

    /** Block-mining requirements (material -> amount) needed to rank up into this rank. */
    public Map<Material, Integer> getRequirements() {
        return requirements;
    }

    /** The chat prefix shown before a player's name, e.g. "§6§l§nKral §f". */
    public String getPrefix() {
        return displayName + " §f";
    }

    /** Next progression rank after this one (only meaningful for non-special ranks). */
    public Rank getNextProgressionRank() {
        if (this == OYUNCU) return CIRAK;
        if (this == CIRAK) return SAVASCI;
        if (this == SAVASCI) return SOVALYE;
        if (this == SOVALYE) return LORD;
        if (this == LORD) return KRAL;
        return null; // KRAL is the top of normal progression; special ranks need /setrank
    }

    public static Rank byName(String name) {
        for (Rank rank : values()) {
            if (rank.name().equalsIgnoreCase(name)) return rank;
        }
        return null;
    }

    /** Ordered map purely for display purposes in /ranks or help commands. */
    public static Map<String, Rank> orderedProgression() {
        Map<String, Rank> map = new LinkedHashMap<>();
        map.put("oyuncu", OYUNCU);
        map.put("cirak", CIRAK);
        map.put("savasci", SAVASCI);
        map.put("sovalye", SOVALYE);
        map.put("lord", LORD);
        map.put("kral", KRAL);
        return map;
    }
}
