package com.mybkn.core.listeners;

import com.mybkn.core.MybknCore;
import com.mybkn.core.rank.Rank;
import com.mybkn.core.rank.RankProgress;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

/**
 * Rewrites chat format based on rank: higher ranks get a flashier prefix
 * AND the message text itself is colored, not just the name. This is
 * what makes a Kral or Kurucu message visibly stand out in chat.
 *
 * Runs at LOW priority so it sets the format before AuthGateListener's
 * HIGHEST-priority cancel check (unlogged-in players never reach here
 * anyway, but priority order matters if more chat plugins are added later).
 */
public class RankChatListener implements Listener {

    private final MybknCore plugin;

    public RankChatListener(MybknCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onChat(AsyncPlayerChatEvent event) {
        if (event.isCancelled()) return;

        RankProgress progress = plugin.getRankManager().getCached(event.getPlayer().getUniqueId());
        Rank rank = (progress != null) ? progress.getCurrentRank() : Rank.OYUNCU;

        String messageColor = messageColorFor(rank);

        // %1$s = prefix+name (from setDisplayName via other plugins, here just player name),
        // %2$s = message
        event.setFormat(rank.getPrefix() + "%1$s §8» " + messageColor + "%2$s");
    }

    /**
     * Low ranks get plain/no color on their message text. As rank goes up,
     * the message itself becomes colored and eventually bold, so a Kral
     * or Kurucu message is unmistakable at a glance.
     */
    private String messageColorFor(Rank rank) {
        return switch (rank) {
            case OYUNCU -> "§7";
            case CIRAK -> "§f";
            case SAVASCI -> "§a";
            case SOVALYE -> "§9";
            case LORD -> "§5";
            case KRAL -> "§6§l";
            case INSAN -> "§b";
            case GUCLU -> "§d§l";
            case YUCE -> "§c§l";
            case YOUTUBER -> "§4§l";
            case KURUCU -> "§4§l§n";
        };
    }
}
