package com.mybkn.core.gui;

import com.mybkn.core.MybknCore;
import com.mybkn.core.data.Account;
import com.mybkn.core.market.MarketItem;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public class MarketGUIListener implements Listener {

    private final MybknCore plugin;

    public MarketGUIListener(MybknCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!MarketGUI.TITLE.equals(event.getView().getTitle())) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null) return;

        String itemId = MarketGUI.extractIdFromLore(clicked);
        if (itemId == null) return;

        MarketItem marketItem = plugin.getMarketManager().getById(itemId);
        if (marketItem == null) return;

        if (!plugin.getAccountManager().isLoggedIn(player.getUniqueId())) {
            player.sendMessage("§cOnce giris yapmalisin!");
            player.closeInventory();
            return;
        }

        Account account = plugin.getAccountManager().getCached(player.getUniqueId());
        if (account == null) return;

        String currency = plugin.getConfig().getString("economy.para-birimi", "₺");

        if (event.getClick() == ClickType.LEFT) {
            // BUY
            if (account.getBalance() < marketItem.getBuyPrice()) {
                player.sendMessage("§cYetersiz bakiye! Gerekli: §e" + marketItem.getBuyPrice() + currency);
                return;
            }
            account.setBalance(account.getBalance() - marketItem.getBuyPrice());
            player.getInventory().addItem(new ItemStack(marketItem.getMaterial(), 1));
            player.sendMessage("§a1x " + marketItem.getDisplayName() + " satin aldin. §7(-"
                    + marketItem.getBuyPrice() + currency + ")");
            persist(player.getUniqueId());

        } else if (event.getClick() == ClickType.RIGHT) {
            // SELL - check the player actually has at least 1 of this material
            if (!player.getInventory().containsAtLeast(new ItemStack(marketItem.getMaterial()), 1)) {
                player.sendMessage("§cEnvanterinde bu urunden yok!");
                return;
            }
            player.getInventory().removeItem(new ItemStack(marketItem.getMaterial(), 1));
            account.setBalance(account.getBalance() + marketItem.getSellPrice());
            player.sendMessage("§a1x " + marketItem.getDisplayName() + " sattin. §7(+"
                    + marketItem.getSellPrice() + currency + ")");
            persist(player.getUniqueId());
        }
    }

    private void persist(java.util.UUID uuid) {
        new BukkitRunnable() {
            @Override
            public void run() {
                plugin.getAccountManager().saveBalance(uuid);
            }
        }.runTaskAsynchronously(plugin);
    }
}
