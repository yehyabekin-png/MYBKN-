package com.mybkn.core.rank;

import org.bukkit.Material;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * In-memory holder for a player's rank + mining progress. Progress
 * counters reset every time the player successfully ranks up, since
 * each rank has its own fresh set of requirements.
 */
public class RankProgress {

    private final UUID uuid;
    private Rank currentRank;
    private final Map<Material, Integer> mined = new HashMap<>();

    public RankProgress(UUID uuid, Rank currentRank) {
        this.uuid = uuid;
        this.currentRank = currentRank;
    }

    public UUID getUuid() {
        return uuid;
    }

    public Rank getCurrentRank() {
        return currentRank;
    }

    public void setCurrentRank(Rank currentRank) {
        this.currentRank = currentRank;
    }

    public int getMined(Material material) {
        return mined.getOrDefault(material, 0);
    }

    public void addMined(Material material, int amount) {
        mined.merge(material, amount, Integer::sum);
    }

    public void resetProgress() {
        mined.clear();
    }

    public Map<Material, Integer> getMinedSnapshot() {
        return mined;
    }

    /** Restores progress counters loaded from the database. */
    public void loadMined(Map<Material, Integer> values) {
        mined.clear();
        mined.putAll(values);
    }

    /**
     * Checks whether all block requirements for the given rank have been
     * met by this player's current mining progress.
     */
    public boolean meetsRequirements(Rank target) {
        for (Map.Entry<Material, Integer> entry : target.getRequirements().entrySet()) {
            if (getMined(entry.getKey()) < entry.getValue()) {
                return false;
            }
        }
        return true;
    }
}
