package com.mybkn.core.listeners;

import com.mybkn.core.MybknCore;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

/**
 * Every time a logged-in player breaks a block, this records it toward
 * their current rankup requirements (RankManager ignores blocks that
 * aren't part of the next rank's task list, so this is cheap to call
 * unconditionally).
 */
public class RankMiningListener implements Listener {

    private final MybknCore plugin;

    public RankMiningListener(MybknCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        if (event.isCancelled()) return;

        Player player = event.getPlayer();
        if (!plugin.getAccountManager().isLoggedIn(player.getUniqueId())) return;

        plugin.getRankManager().recordMined(player.getUniqueId(), event.getBlock().getType(), 1);
    }
}
