package com.mybkn.core.data;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

/**
 * Manages the connection pool to the shared MySQL database.
 *
 * Why MySQL instead of SQLite: this plugin is meant to run on every
 * backend server behind the Velocity proxy (lobby, survival, etc).
 * If each server kept its own SQLite file, a player's balance and
 * login state would reset every time they switched servers. MySQL
 * lets every server read/write the same accounts table.
 */
public class DatabaseManager {

    private final Plugin plugin;
    private final Logger logger;
    private HikariDataSource dataSource;

    public DatabaseManager(Plugin plugin) {
        this.plugin = plugin;
        this.logger = plugin.getLogger();
    }

    public boolean connect() {
        FileConfiguration cfg = plugin.getConfig();
        String host = cfg.getString("database.host", "127.0.0.1");
        int port = cfg.getInt("database.port", 3306);
        String database = cfg.getString("database.database", "mybkn");
        String username = cfg.getString("database.username", "mybkn_user");
        String password = cfg.getString("database.password", "");
        int poolSize = cfg.getInt("database.pool-size", 10);

        String jdbcUrl = "jdbc:mysql://" + host + ":" + port + "/" + database
                + "?useSSL=false&allowPublicKeyRetrieval=true&characterEncoding=utf8";

        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(jdbcUrl);
        hikariConfig.setUsername(username);
        hikariConfig.setPassword(password);
        hikariConfig.setMaximumPoolSize(poolSize);
        hikariConfig.setMinimumIdle(2);
        hikariConfig.setPoolName("MybknPool");
        hikariConfig.setConnectionTimeout(10000);

        try {
            this.dataSource = new HikariDataSource(hikariConfig);
            createTables();
            logger.info("[MybknCore] MySQL baglantisi basarili: " + host + ":" + port + "/" + database);
            return true;
        } catch (Exception e) {
            logger.severe("[MybknCore] MySQL baglantisi BASARISIZ! config.yml dosyasindaki");
            logger.severe("[MybknCore] database ayarlarini kontrol edin. Hata: " + e.getMessage());
            return false;
        }
    }

    private void createTables() throws SQLException {
        String accountsTable = """
            CREATE TABLE IF NOT EXISTS mybkn_accounts (
                uuid VARCHAR(36) PRIMARY KEY,
                username VARCHAR(16) NOT NULL,
                password_hash VARCHAR(128) NOT NULL,
                balance DOUBLE NOT NULL DEFAULT 0,
                is_admin TINYINT(1) NOT NULL DEFAULT 0,
                created_at BIGINT NOT NULL,
                last_login BIGINT
            )
        """;

        String transactionsTable = """
            CREATE TABLE IF NOT EXISTS mybkn_transactions (
                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                actor_uuid VARCHAR(36) NOT NULL,
                target_uuid VARCHAR(36) NOT NULL,
                amount DOUBLE NOT NULL,
                type VARCHAR(32) NOT NULL,
                note VARCHAR(255),
                created_at BIGINT NOT NULL
            )
        """;

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(accountsTable);
            stmt.execute(transactionsTable);
        }
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    public void close() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }
}
