package com.mybkn.core.rank;

import com.mybkn.core.MybknCore;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Owns the mybkn_ranks and mybkn_rank_progress tables, and the in-memory
 * cache of online players' rank state. Mirrors the pattern used by
 * AccountManager: cache for fast access, MySQL for persistence shared
 * across every backend server.
 */
public class RankManager {

    private final MybknCore plugin;
    private final Map<UUID, RankProgress> cache = new ConcurrentHashMap<>();

    public RankManager(MybknCore plugin) {
        this.plugin = plugin;
    }

    public void createTables() throws SQLException {
        String ranksTable = """
            CREATE TABLE IF NOT EXISTS mybkn_ranks (
                uuid VARCHAR(36) PRIMARY KEY,
                rank_name VARCHAR(32) NOT NULL DEFAULT 'OYUNCU',
                updated_at BIGINT NOT NULL
            )
        """;

        // one row per (uuid, material) tracking how many of that block
        // the player has mined since their last rankup
        String progressTable = """
            CREATE TABLE IF NOT EXISTS mybkn_rank_progress (
                uuid VARCHAR(36) NOT NULL,
                material VARCHAR(64) NOT NULL,
                amount INT NOT NULL DEFAULT 0,
                PRIMARY KEY (uuid, material)
            )
        """;

        try (Connection conn = plugin.getDatabaseManager().getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(ranksTable);
            stmt.execute(progressTable);
        }
    }

    // ---------------- loading ----------------

    /** Loads (or creates) a player's rank progress from the DB. Call off-thread. */
    public RankProgress load(UUID uuid) {
        Rank rank = Rank.OYUNCU;

        try (Connection conn = plugin.getDatabaseManager().getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT rank_name FROM mybkn_ranks WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        Rank loaded = Rank.byName(rs.getString("rank_name"));
                        if (loaded != null) rank = loaded;
                    } else {
                        // first time we see this player - insert default row
                        try (PreparedStatement insert = conn.prepareStatement(
                                "INSERT INTO mybkn_ranks (uuid, rank_name, updated_at) VALUES (?, 'OYUNCU', ?)")) {
                            insert.setString(1, uuid.toString());
                            insert.setLong(2, System.currentTimeMillis());
                            insert.executeUpdate();
                        }
                    }
                }
            }

            RankProgress progress = new RankProgress(uuid, rank);

            Map<org.bukkit.Material, Integer> mined = new HashMap<>();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT material, amount FROM mybkn_rank_progress WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        try {
                            org.bukkit.Material mat = org.bukkit.Material.valueOf(rs.getString("material"));
                            mined.put(mat, rs.getInt("amount"));
                        } catch (IllegalArgumentException ignored) {
                            // material no longer exists in this MC version, skip
                        }
                    }
                }
            }
            progress.loadMined(mined);

            cache.put(uuid, progress);
            return progress;

        } catch (SQLException e) {
            plugin.getLogger().severe("[MybknCore] Rank yuklenemedi: " + e.getMessage());
            RankProgress fallback = new RankProgress(uuid, Rank.OYUNCU);
            cache.put(uuid, fallback);
            return fallback;
        }
    }

    public RankProgress getCached(UUID uuid) {
        return cache.get(uuid);
    }

    public void unload(UUID uuid) {
        cache.remove(uuid);
    }

    // ---------------- mining progress ----------------

    /** Call when a player breaks a block. Cheap in-memory update; persisted periodically/async. */
    public void recordMined(UUID uuid, org.bukkit.Material material, int amount) {
        RankProgress progress = cache.get(uuid);
        if (progress == null) return;

        Rank current = progress.getCurrentRank();
        Rank next = current.getNextProgressionRank();
        if (next == null) return; // already at KRAL or a special rank, no progression tracking needed
        if (!next.getRequirements().containsKey(material)) return; // not a tracked block for this rank

        progress.addMined(material, amount);
        persistProgressAsync(uuid, material, progress.getMined(material));
    }

    private void persistProgressAsync(UUID uuid, org.bukkit.Material material, int newAmount) {
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                try (Connection conn = plugin.getDatabaseManager().getConnection();
                     PreparedStatement ps = conn.prepareStatement(
                             "INSERT INTO mybkn_rank_progress (uuid, material, amount) VALUES (?, ?, ?) " +
                                     "ON DUPLICATE KEY UPDATE amount = ?")) {
                    ps.setString(1, uuid.toString());
                    ps.setString(2, material.name());
                    ps.setInt(3, newAmount);
                    ps.setInt(4, newAmount);
                    ps.executeUpdate();
                } catch (SQLException e) {
                    plugin.getLogger().warning("[MybknCore] Rank ilerlemesi kaydedilemedi: " + e.getMessage());
                }
            }
        }.runTaskAsynchronously(plugin);
    }

    private void clearProgressAsync(UUID uuid) {
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                try (Connection conn = plugin.getDatabaseManager().getConnection();
                     PreparedStatement ps = conn.prepareStatement(
                             "DELETE FROM mybkn_rank_progress WHERE uuid = ?")) {
                    ps.setString(1, uuid.toString());
                    ps.executeUpdate();
                } catch (SQLException e) {
                    plugin.getLogger().warning("[MybknCore] Rank ilerlemesi temizlenemedi: " + e.getMessage());
                }
            }
        }.runTaskAsynchronously(plugin);
    }

    // ---------------- rank changes ----------------

    /** Persists a rank change (from /rankup or /setrank) to the database. */
    public void persistRank(UUID uuid, Rank rank) {
        new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                try (Connection conn = plugin.getDatabaseManager().getConnection();
                     PreparedStatement ps = conn.prepareStatement(
                             "INSERT INTO mybkn_ranks (uuid, rank_name, updated_at) VALUES (?, ?, ?) " +
                                     "ON DUPLICATE KEY UPDATE rank_name = ?, updated_at = ?")) {
                    ps.setString(1, uuid.toString());
                    ps.setString(2, rank.name());
                    ps.setLong(3, System.currentTimeMillis());
                    ps.setString(4, rank.name());
                    ps.setLong(5, System.currentTimeMillis());
                    ps.executeUpdate();
                } catch (SQLException e) {
                    plugin.getLogger().severe("[MybknCore] Rank kaydedilemedi: " + e.getMessage());
                }
            }
        }.runTaskAsynchronously(plugin);
    }

    /**
     * Performs a rankup: assumes the caller already verified requirements
     * and balance. Resets progress counters for the new rank's tasks.
     */
    public void applyRankup(UUID uuid, Rank newRank) {
        RankProgress progress = cache.get(uuid);
        if (progress != null) {
            progress.setCurrentRank(newRank);
            progress.resetProgress();
        }
        persistRank(uuid, newRank);
        clearProgressAsync(uuid);
    }

    /** Looks up rank for a possibly-offline player by uuid, hitting the DB directly. */
    public Rank getRankDirect(UUID uuid) {
        try (Connection conn = plugin.getDatabaseManager().getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT rank_name FROM mybkn_ranks WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Rank rank = Rank.byName(rs.getString("rank_name"));
                    if (rank != null) return rank;
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("[MybknCore] getRankDirect hatasi: " + e.getMessage());
        }
        return Rank.OYUNCU;
    }
}
