package com.mybkn.core.commands;

import com.mybkn.core.MybknCore;
import com.mybkn.core.data.Account;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * /eco give <oyuncu> <miktar>   -> bakiyeye ekler (sinirsiz)
 * /eco take <oyuncu> <miktar>   -> bakiyeden duser
 * /eco set  <oyuncu> <miktar>   -> bakiyeyi sabit deger yapar
 *
 * Permission: mybkn.admin.eco (default: op)
 * This is the "adminler kendine istedigi kadar para atabilsin" command -
 * an admin can target themselves too: /eco give kendi_adin 999999999
 */
public class EcoCommand implements CommandExecutor {

    private final MybknCore plugin;

    public EcoCommand(MybknCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mybkn.admin.eco")) {
            sender.sendMessage("§cBu komutu kullanma yetkin yok.");
            return true;
        }

        if (args.length != 3) {
            sender.sendMessage("§cKullanim: §e/eco <give|take|set> <oyuncu> <miktar>");
            return true;
        }

        String action = args[0].toLowerCase();
        String targetName = args[1];
        double amount;
        try {
            amount = Double.parseDouble(args[2]);
        } catch (NumberFormatException e) {
            sender.sendMessage("§cMiktar sayi olmali!");
            return true;
        }

        if (!action.equals("give") && !action.equals("take") && !action.equals("set")) {
            sender.sendMessage("§cGecersiz islem! give, take veya set kullan.");
            return true;
        }

        if (amount < 0) {
            sender.sendMessage("§cMiktar negatif olamaz!");
            return true;
        }

        String currency = plugin.getConfig().getString("economy.para-birimi", "₺");
        Player targetOnline = Bukkit.getPlayerExact(targetName);

        if (targetOnline != null) {
            Account targetAcc = plugin.getAccountManager().getCached(targetOnline.getUniqueId());
            if (targetAcc == null) {
                sender.sendMessage("§cBu oyuncu henuz giris yapmamis / hesabi yuklenmemis.");
                return true;
            }

            double newBalance = switch (action) {
                case "give" -> targetAcc.getBalance() + amount;
                case "take" -> Math.max(0, targetAcc.getBalance() - amount);
                default -> amount; // set
            };

            targetAcc.setBalance(newBalance);

            sender.sendMessage("§a[ECO] §f" + targetName + "'in bakiyesi: §e"
                    + format(newBalance) + currency + " §7(" + action + " " + format(amount) + ")");
            targetOnline.sendMessage("§e[MYBKN] §fBir admin bakiyeni guncelledi. Yeni bakiyen: §a"
                    + format(newBalance) + currency);

            new BukkitRunnable() {
                @Override
                public void run() {
                    plugin.getAccountManager().saveBalance(targetOnline.getUniqueId());
                    plugin.getAccountManager().logTransaction(
                            targetOnline.getUniqueId(), targetOnline.getUniqueId(), amount, "ECO_" + action.toUpperCase(),
                            "admin:" + sender.getName());
                }
            }.runTaskAsynchronously(plugin);
            return true;
        }

        // offline target
        new BukkitRunnable() {
            @Override
            public void run() {
                Account offlineAcc = plugin.getAccountManager().findByUsername(targetName);
                if (offlineAcc == null) {
                    Bukkit.getScheduler().runTask(plugin, () ->
                            sender.sendMessage("§cBoyle bir oyuncu/hesap bulunamadi."));
                    return;
                }

                double newBalance = switch (action) {
                    case "give" -> offlineAcc.getBalance() + amount;
                    case "take" -> Math.max(0, offlineAcc.getBalance() - amount);
                    default -> amount;
                };

                plugin.getAccountManager().setBalanceDirect(offlineAcc.getUuid(), newBalance);
                plugin.getAccountManager().logTransaction(
                        offlineAcc.getUuid(), offlineAcc.getUuid(), amount, "ECO_" + action.toUpperCase(),
                        "admin:" + sender.getName());

                Bukkit.getScheduler().runTask(plugin, () ->
                        sender.sendMessage("§a[ECO] §f" + targetName + "'in bakiyesi: §e"
                                + format(newBalance) + currency + " §7(cevrimdisi)"));
            }
        }.runTaskAsynchronously(plugin);

        return true;
    }

    private String format(double value) {
        return String.format("%,.2f", value);
    }
}
