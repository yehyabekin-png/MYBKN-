package com.mybkn.core.data;

import java.util.UUID;

/**
 * Plain data holder for a player's MYBKN account.
 */
public class Account {

    private final UUID uuid;
    private String username;
    private String passwordHash;
    private double balance;
    private boolean admin;
    private boolean loggedIn;

    public Account(UUID uuid, String username, String passwordHash, double balance, boolean admin) {
        this.uuid = uuid;
        this.username = username;
        this.passwordHash = passwordHash;
        this.balance = balance;
        this.admin = admin;
        this.loggedIn = false;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public void setLoggedIn(boolean loggedIn) {
        this.loggedIn = loggedIn;
    }
}
