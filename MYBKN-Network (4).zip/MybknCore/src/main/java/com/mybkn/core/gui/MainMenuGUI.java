package com.mybkn.core.gui;

import com.mybkn.core.MybknCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * The main MYBKN hub menu - a 27-slot panel with shortcuts to the
 * features players use most (market, balance, pay) and, for admins,
 * a shortcut into the eco tools. This is the "yandaki Aesir menusu"
 * equivalent for MYBKN.
 */
public class MainMenuGUI {

    public static final String TITLE = "§8§lMYBKN §7| Ana Menu";

    public static Inventory build(MybknCore plugin, Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);

        fillBorder(inv);

        inv.setItem(11, item(Material.EMERALD, "§a§lMarket", List.of(
                "§7Esya al ve sat.",
                "",
                "§eTiklayarak ac"
        )));

        inv.setItem(13, item(Material.GOLD_INGOT, "§e§lBakiyem", List.of(
                "§7Guncel bakiyeni gosterir.",
                "",
                "§eTiklayarak gor"
        )));

        inv.setItem(15, item(Material.PAPER, "§b§lYardim", List.of(
                "§7Tum komutlarin listesi.",
                "",
                "§eTiklayarak gor"
        )));

        if (player.hasPermission("mybkn.admin")) {
            inv.setItem(22, item(Material.NETHER_STAR, "§c§lAdmin Paneli", List.of(
                    "§7/eco give|take|set komutlari",
                    "§7ile ekonomiyi yonet.",
                    "",
                    "§eTiklayarak komut listesini gor"
            )));
        }

        return inv;
    }

    private static void fillBorder(Inventory inv) {
        ItemStack filler = item(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, filler);
        }
    }

    private static ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore != null) meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }
}
