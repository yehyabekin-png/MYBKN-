package com.mybkn.core.market;

import com.mybkn.core.MybknCore;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MarketManager {

    private final MybknCore plugin;
    private final List<MarketItem> items = new ArrayList<>();

    public MarketManager(MybknCore plugin) {
        this.plugin = plugin;
    }

    public void loadFromConfig() {
        items.clear();
        List<?> rawList = plugin.getConfig().getList("market");
        if (rawList == null) return;

        for (Object obj : rawList) {
            if (!(obj instanceof Map<?, ?> map)) continue;

            try {
                String id = String.valueOf(map.get("id"));
                String name = String.valueOf(map.get("isim"));
                Material material = Material.valueOf(String.valueOf(map.get("material")));
                double buy = toDouble(map.get("alis-fiyati"));
                double sell = toDouble(map.get("satis-fiyati"));

                items.add(new MarketItem(id, name, material, buy, sell));
            } catch (Exception e) {
                plugin.getLogger().warning("[MybknCore] Market itemi yuklenemedi: " + e.getMessage());
            }
        }
    }

    private double toDouble(Object o) {
        if (o instanceof Number n) return n.doubleValue();
        return Double.parseDouble(String.valueOf(o));
    }

    public List<MarketItem> getItems() {
        return items;
    }

    public int getItemCount() {
        return items.size();
    }

    public MarketItem getById(String id) {
        for (MarketItem item : items) {
            if (item.getId().equalsIgnoreCase(id)) return item;
        }
        return null;
    }
}
