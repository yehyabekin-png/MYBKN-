package com.mybkn.core.commands;

import com.mybkn.core.MybknCore;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class LoginCommand implements CommandExecutor {

    private final MybknCore plugin;

    public LoginCommand(MybknCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Bu komut sadece oyun icinde kullanilabilir.");
            return true;
        }

        if (plugin.getAccountManager().isLoggedIn(player.getUniqueId())) {
            player.sendMessage("§eZaten giris yapmissin!");
            return true;
        }

        if (args.length != 1) {
            player.sendMessage("§cKullanim: §e/login <sifre>");
            return true;
        }

        String password = args[0];

        new BukkitRunnable() {
            @Override
            public void run() {
                boolean exists = plugin.getAccountManager().accountExists(player.getUniqueId());
                if (!exists) {
                    Bukkit.getScheduler().runTask(plugin, () ->
                            player.sendMessage("§cHesabin yok! Once §a/register <sifre> <sifre-tekrar> §cile kayit ol."));
                    return;
                }

                boolean ok = plugin.getAccountManager().login(player.getUniqueId(), password);

                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (ok) {
                        player.sendMessage("§a§lGiris basarili! §fHosgeldin " + player.getName() + ".");
                        var acc = plugin.getAccountManager().getCached(player.getUniqueId());
                        if (acc != null) {
                            player.sendMessage("§7Bakiyen: §e" + acc.getBalance()
                                    + plugin.getConfig().getString("economy.para-birimi", "₺"));
                        }
                    } else {
                        player.sendMessage("§cSifre yanlis!");
                    }
                });
            }
        }.runTaskAsynchronously(plugin);

        return true;
    }
}
