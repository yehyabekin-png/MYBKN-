package com.mybkn.core.commands;

import com.mybkn.core.MybknCore;
import com.mybkn.core.data.Account;
import com.mybkn.core.rank.Rank;
import com.mybkn.core.rank.RankProgress;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;

public class RankupCommand implements CommandExecutor {

    private final MybknCore plugin;

    public RankupCommand(MybknCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Bu komut sadece oyun icinde kullanilabilir.");
            return true;
        }

        if (!plugin.getAccountManager().isLoggedIn(player.getUniqueId())) {
            player.sendMessage("§cOnce giris yapmalisin! §7/login <sifre>");
            return true;
        }

        RankProgress progress = plugin.getRankManager().getCached(player.getUniqueId());
        if (progress == null) {
            player.sendMessage("§cRank bilgin henuz yuklenmedi, biraz bekleyip tekrar dene.");
            return true;
        }

        Rank current = progress.getCurrentRank();
        Rank next = current.getNextProgressionRank();

        if (next == null) {
            player.sendMessage("§e§l[RANKUP] §fSen zaten en yuksek normal ranktasin: " + current.getDisplayName());
            player.sendMessage("§7Bir ustu sadece adminler tarafindan verilebilir.");
            return true;
        }

        // check task requirements
        if (!progress.meetsRequirements(next)) {
            player.sendMessage("§c§l[RANKUP] §fHenuz hazir degilsin! Eksik gorevler:");
            for (Map.Entry<Material, Integer> entry : next.getRequirements().entrySet()) {
                int have = progress.getMined(entry.getKey());
                int need = entry.getValue();
                String status = have >= need ? "§a✔" : "§c✘";
                player.sendMessage("  " + status + " §f" + entry.getKey().name() + "§7: " + have + "/" + need);
            }
            return true;
        }

        // check money cost
        Account account = plugin.getAccountManager().getCached(player.getUniqueId());
        if (account == null) {
            player.sendMessage("§cHesap bilgin yuklenemedi.");
            return true;
        }

        double cost = next.getRankupMoneyCost();
        String currency = plugin.getConfig().getString("economy.para-birimi", "₺");

        if (account.getBalance() < cost) {
            player.sendMessage("§c§l[RANKUP] §fGorevler tamam ama paran yetmiyor! Gereken: §e"
                    + cost + currency + " §f| Bakiyen: §e" + account.getBalance() + currency);
            return true;
        }

        // all checks passed - apply rankup
        account.setBalance(account.getBalance() - cost + next.getMoneyReward());
        plugin.getRankManager().applyRankup(player.getUniqueId(), next);

        if (next.getItemReward() != null) {
            player.getInventory().addItem(new ItemStack(next.getItemReward(), 1));
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                plugin.getAccountManager().saveBalance(player.getUniqueId());
            }
        }.runTaskAsynchronously(plugin);

        announceRankup(player, current, next, currency);
        return true;
    }

    private void announceRankup(Player player, Rank from, Rank to, String currency) {
        player.sendMessage("§8§m--------------------------------");
        player.sendMessage("§a§l✔ RANK YUKSELTTIN!");
        player.sendMessage("§7" + from.getDisplayName() + " §f➜ " + to.getDisplayName());
        if (to.getMoneyReward() > 0) {
            player.sendMessage("§7Odul: §a+" + to.getMoneyReward() + currency);
        }
        if (to.getItemReward() != null) {
            player.sendMessage("§7Odul: §a1x " + to.getItemReward().name());
        }
        player.sendMessage("§8§m--------------------------------");

        // broadcast to everyone so rankups feel like an achievement
        player.getServer().broadcastMessage(
                "§6§l[RANKUP] §f" + player.getName() + " §7artik " + to.getDisplayName() + "§7!");
    }
}
