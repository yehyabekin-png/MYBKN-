package com.mybkn.core.commands;

import com.mybkn.core.MybknCore;
import com.mybkn.core.rank.Rank;
import com.mybkn.core.rank.RankProgress;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Map;

public class RankCommand implements CommandExecutor {

    private final MybknCore plugin;

    public RankCommand(MybknCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Bu komut sadece oyun icinde kullanilabilir.");
            return true;
        }

        if (!plugin.getAccountManager().isLoggedIn(player.getUniqueId())) {
            player.sendMessage("§cOnce giris yapmalisin! §7/login <sifre>");
            return true;
        }

        RankProgress progress = plugin.getRankManager().getCached(player.getUniqueId());
        if (progress == null) {
            player.sendMessage("§cRank bilgin henuz yuklenmedi.");
            return true;
        }

        Rank current = progress.getCurrentRank();
        Rank next = current.getNextProgressionRank();

        player.sendMessage("§8§m--------------------------------");
        player.sendMessage("§e§lRANK BILGIN");
        player.sendMessage("§7Su anki rank: " + current.getDisplayName());

        if (next == null) {
            player.sendMessage("§7Sonraki: §8en yuksek normal rank - ustu adminden");
        } else {
            player.sendMessage("§7Sonraki rank: " + next.getDisplayName());
            player.sendMessage("§7Gerekli paran: §e" + next.getRankupMoneyCost()
                    + plugin.getConfig().getString("economy.para-birimi", "₺"));
            player.sendMessage("§7Gorevler:");
            for (Map.Entry<Material, Integer> entry : next.getRequirements().entrySet()) {
                int have = progress.getMined(entry.getKey());
                int need = entry.getValue();
                String status = have >= need ? "§a✔" : "§c✘";
                player.sendMessage("  " + status + " §f" + entry.getKey().name() + "§7: " + have + "/" + need);
            }
            player.sendMessage("§7Hazir olunca: §a/rankup");
        }
        player.sendMessage("§8§m--------------------------------");
        return true;
    }
}
