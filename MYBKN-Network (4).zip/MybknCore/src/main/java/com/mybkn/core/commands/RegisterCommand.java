package com.mybkn.core.commands;

import com.mybkn.core.MybknCore;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class RegisterCommand implements CommandExecutor {

    private final MybknCore plugin;

    public RegisterCommand(MybknCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Bu komut sadece oyun icinde kullanilabilir.");
            return true;
        }

        if (args.length != 2) {
            player.sendMessage("§cKullanim: §e/register <sifre> <sifre-tekrar>");
            return true;
        }

        String password = args[0];
        String confirm = args[1];

        if (!password.equals(confirm)) {
            player.sendMessage("§cSifreler birbirini tutmuyor!");
            return true;
        }

        if (password.length() < 4) {
            player.sendMessage("§cSifre en az 4 karakter olmali!");
            return true;
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                if (plugin.getAccountManager().accountExists(player.getUniqueId())) {
                    player.sendMessage("§cZaten kayitli bir hesabin var! §7/login <sifre>");
                    return;
                }

                boolean ok = plugin.getAccountManager().register(
                        player.getUniqueId(), player.getName(), password);

                if (ok) {
                    player.sendMessage("§a§lKayit basarili! §fArtik §a/login " + password + " §file (veya kendi sifrenle) giris yapabilirsin.");
                    player.sendMessage("§7Baslangic bakiyen: §e" + plugin.getConfig().getDouble("economy.baslangic-bakiyesi", 500.0)
                            + plugin.getConfig().getString("economy.para-birimi", "₺"));
                } else {
                    player.sendMessage("§cKayit sirasinda bir hata olustu, lutfen tekrar dene.");
                }
            }
        }.runTaskAsynchronously(plugin);

        return true;
    }
}
