package com.mybkn.core.market;

import org.bukkit.Material;

public class MarketItem {

    private final String id;
    private final String displayName;
    private final Material material;
    private final double buyPrice;
    private final double sellPrice;

    public MarketItem(String id, String displayName, Material material, double buyPrice, double sellPrice) {
        this.id = id;
        this.displayName = displayName;
        this.material = material;
        this.buyPrice = buyPrice;
        this.sellPrice = sellPrice;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getMaterial() {
        return material;
    }

    public double getBuyPrice() {
        return buyPrice;
    }

    public double getSellPrice() {
        return sellPrice;
    }
}
