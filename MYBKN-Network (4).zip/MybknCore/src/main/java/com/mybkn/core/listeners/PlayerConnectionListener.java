package com.mybkn.core.listeners;

import com.mybkn.core.MybknCore;
import com.mybkn.core.data.Account;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

/**
 * Loads the account from the database (off the main thread) when a
 * player joins, and saves their balance back when they leave.
 */
public class PlayerConnectionListener implements Listener {

    private final MybknCore plugin;

    public PlayerConnectionListener(MybknCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        new BukkitRunnable() {
            @Override
            public void run() {
                boolean exists = plugin.getAccountManager().accountExists(uuid);
                plugin.getRankManager().load(uuid);

                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!player.isOnline()) return;

                    if (!exists) {
                        player.sendMessage("§e§l[MYBKN] §fHosgeldin! Hesabin yok, kayit olman gerekiyor.");
                        player.sendMessage("§7Kullanim: §a/register <sifre> <sifre-tekrar>");
                    } else {
                        Account acc = plugin.getAccountManager().loadAccount(uuid);
                        player.sendMessage("§e§l[MYBKN] §fHosgeldin geri " + player.getName() + "!");
                        player.sendMessage("§7Giris yapmak icin: §a/login <sifre>");
                    }
                });
            }
        }.runTaskAsynchronously(plugin);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();

        new BukkitRunnable() {
            @Override
            public void run() {
                plugin.getAccountManager().saveBalance(uuid);
                plugin.getAccountManager().unload(uuid);
                plugin.getRankManager().unload(uuid);
            }
        }.runTaskAsynchronously(plugin);
    }
}
