package com.mybkn.core.listeners;

import com.mybkn.core.MybknCore;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.util.Locale;
import java.util.Set;

/**
 * Prevents players who have not logged in yet from moving, chatting,
 * taking damage, or running commands other than /login and /register.
 * This is what "giris yapmadan hareket edemiyor" servers like Aesir MC do.
 */
public class AuthGateListener implements Listener {

    private static final Set<String> ALLOWED_COMMANDS = Set.of(
            "/login", "/register", "/l", "/reg"
    );

    private final MybknCore plugin;

    public AuthGateListener(MybknCore plugin) {
        this.plugin = plugin;
    }

    private boolean isRestricted(Player player) {
        if (player.hasPermission("mybkn.admin.bypass")) return false;
        return !plugin.getAccountManager().isLoggedIn(player.getUniqueId());
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (!plugin.getConfig().getBoolean("auth.giris-yapmadan-hareket", false)
                && isRestricted(event.getPlayer())) {
            // only cancel actual movement, not head-turns, so players aren't stuck stuttering
            if (event.getFrom().getX() != event.getTo().getX()
                    || event.getFrom().getY() != event.getTo().getY()
                    || event.getFrom().getZ() != event.getTo().getZ()) {
                event.setTo(event.getFrom());
            }
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        if (!plugin.getConfig().getBoolean("auth.giris-yapmadan-sohbet", false)
                && isRestricted(event.getPlayer())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§c[MYBKN] Sohbet etmek icin once giris yapmalisin! §7/login <sifre>");
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player && isRestricted(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!isRestricted(event.getPlayer())) return;

        String base = event.getMessage().split(" ")[0].toLowerCase(Locale.ROOT);
        if (!ALLOWED_COMMANDS.contains(base)) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§c[MYBKN] Once giris yapmalisin! §7/login <sifre>");
        }
    }
}
