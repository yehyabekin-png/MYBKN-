package com.mybkn.core.gui;

import com.mybkn.core.MybknCore;
import com.mybkn.core.data.Account;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class MainMenuGUIListener implements Listener {

    private final MybknCore plugin;

    public MainMenuGUIListener(MybknCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!MainMenuGUI.TITLE.equals(event.getView().getTitle())) return;
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getItemMeta() == null) return;

        ItemMeta meta = clicked.getItemMeta();
        String name = meta.getDisplayName();
        if (name == null) return;

        if (name.contains("Market")) {
            player.closeInventory();
            player.openInventory(MarketGUI.build(plugin));

        } else if (name.contains("Bakiyem")) {
            if (!plugin.getAccountManager().isLoggedIn(player.getUniqueId())) {
                player.sendMessage("§cOnce giris yapmalisin!");
                return;
            }
            Account acc = plugin.getAccountManager().getCached(player.getUniqueId());
            if (acc != null) {
                player.sendMessage("§e§l[MYBKN] §fBakiyen: §a"
                        + acc.getBalance() + plugin.getConfig().getString("economy.para-birimi", "₺"));
            }

        } else if (name.contains("Yardim")) {
            player.sendMessage("§8§m----------------------------");
            player.sendMessage("§e§lMYBKN KOMUTLARI");
            player.sendMessage("§a/register <sifre> <sifre-tekrar> §7- kayit ol");
            player.sendMessage("§a/login <sifre> §7- giris yap");
            player.sendMessage("§a/bal §7- bakiyeni gor");
            player.sendMessage("§a/pay <oyuncu> <miktar> §7- para gonder");
            player.sendMessage("§a/market §7- marketi ac");
            player.sendMessage("§a/mybkn §7- bu menuyu ac");
            player.sendMessage("§8§m----------------------------");

        } else if (name.contains("Admin Paneli")) {
            if (!player.hasPermission("mybkn.admin")) return;
            player.sendMessage("§8§m----------------------------");
            player.sendMessage("§c§lADMIN KOMUTLARI");
            player.sendMessage("§c/eco give <oyuncu> <miktar> §7- para ekle");
            player.sendMessage("§c/eco take <oyuncu> <miktar> §7- para cek");
            player.sendMessage("§c/eco set <oyuncu> <miktar> §7- bakiyeyi sabitle");
            player.sendMessage("§8§m----------------------------");
        }
    }
}
