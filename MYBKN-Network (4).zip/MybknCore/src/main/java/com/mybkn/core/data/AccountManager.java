package com.mybkn.core.data;

import com.mybkn.core.MybknCore;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles everything related to accounts: registration, login, password
 * verification, and balance changes. Keeps an in-memory cache of online
 * players' accounts so we don't hit the database on every command.
 */
public class AccountManager {

    private final MybknCore plugin;
    private final DatabaseManager db;
    private final Map<UUID, Account> cache = new ConcurrentHashMap<>();
    private final SecureRandom random = new SecureRandom();

    public AccountManager(MybknCore plugin, DatabaseManager db) {
        this.plugin = plugin;
        this.db = db;
    }

    // ---------- password hashing (PBKDF2-style salted SHA-256) ----------

    private String hash(String password, String saltB64) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(Base64.getDecoder().decode(saltB64));
            byte[] hashed = digest.digest(password.getBytes());
            // run a few extra rounds to slow down brute force
            for (int i = 0; i < 10_000; i++) {
                hashed = digest.digest(hashed);
            }
            return Base64.getEncoder().encodeToString(hashed);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    private String newSalt() {
        byte[] saltBytes = new byte[16];
        random.nextBytes(saltBytes);
        return Base64.getEncoder().encodeToString(saltBytes);
    }

    /** Stored format: salt$hash */
    private String buildStoredHash(String password) {
        String salt = newSalt();
        return salt + "$" + hash(password, salt);
    }

    private boolean verify(String password, String stored) {
        String[] parts = stored.split("\\$", 2);
        if (parts.length != 2) return false;
        String salt = parts[0];
        String expectedHash = parts[1];
        return hash(password, salt).equals(expectedHash);
    }

    // ---------- database-backed operations (call off the main thread) ----------

    public boolean accountExists(UUID uuid) {
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT 1 FROM mybkn_accounts WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("[MybknCore] accountExists hatasi: " + e.getMessage());
            return false;
        }
    }

    public Account loadAccount(UUID uuid) {
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT username, password_hash, balance, is_admin FROM mybkn_accounts WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Account acc = new Account(
                            uuid,
                            rs.getString("username"),
                            rs.getString("password_hash"),
                            rs.getDouble("balance"),
                            rs.getBoolean("is_admin")
                    );
                    cache.put(uuid, acc);
                    return acc;
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("[MybknCore] loadAccount hatasi: " + e.getMessage());
        }
        return null;
    }

    public boolean register(UUID uuid, String username, String password) {
        double startBalance = plugin.getConfig().getDouble("economy.baslangic-bakiyesi", 500.0);
        String storedHash = buildStoredHash(password);

        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO mybkn_accounts (uuid, username, password_hash, balance, is_admin, created_at) " +
                             "VALUES (?, ?, ?, ?, 0, ?)")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, username);
            ps.setString(3, storedHash);
            ps.setDouble(4, startBalance);
            ps.setLong(5, System.currentTimeMillis());
            ps.executeUpdate();

            Account acc = new Account(uuid, username, storedHash, startBalance, false);
            cache.put(uuid, acc);
            return true;
        } catch (SQLException e) {
            plugin.getLogger().severe("[MybknCore] register hatasi: " + e.getMessage());
            return false;
        }
    }

    /** Returns true if password matches and marks the account logged in. */
    public boolean login(UUID uuid, String password) {
        Account acc = cache.get(uuid);
        if (acc == null) {
            acc = loadAccount(uuid);
        }
        if (acc == null) return false;

        boolean ok = verify(password, acc.getPasswordHash());
        if (ok) {
            acc.setLoggedIn(true);
            updateLastLogin(uuid);
        }
        return ok;
    }

    private void updateLastLogin(UUID uuid) {
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE mybkn_accounts SET last_login = ? WHERE uuid = ?")) {
            ps.setLong(1, System.currentTimeMillis());
            ps.setString(2, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("[MybknCore] last_login guncellenemedi: " + e.getMessage());
        }
    }

    public Account getCached(UUID uuid) {
        return cache.get(uuid);
    }

    public boolean isLoggedIn(UUID uuid) {
        Account acc = cache.get(uuid);
        return acc != null && acc.isLoggedIn();
    }

    public void unload(UUID uuid) {
        cache.remove(uuid);
    }

    // ---------- balance operations ----------

    /** Persists the cached balance to the database. */
    public void saveBalance(UUID uuid) {
        Account acc = cache.get(uuid);
        if (acc == null) return;
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE mybkn_accounts SET balance = ? WHERE uuid = ?")) {
            ps.setDouble(1, acc.getBalance());
            ps.setString(2, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("[MybknCore] saveBalance hatasi: " + e.getMessage());
        }
    }

    public void logTransaction(UUID actor, UUID target, double amount, String type, String note) {
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO mybkn_transactions (actor_uuid, target_uuid, amount, type, note, created_at) " +
                             "VALUES (?, ?, ?, ?, ?, ?)")) {
            ps.setString(1, actor.toString());
            ps.setString(2, target.toString());
            ps.setDouble(3, amount);
            ps.setString(4, type);
            ps.setString(5, note);
            ps.setLong(6, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().warning("[MybknCore] islem kaydedilemedi: " + e.getMessage());
        }
    }

    /**
     * Looks up a balance/account for an offline player by username.
     * Used by /eco when the target isn't online. Returns null if no
     * account exists with that username.
     */
    public Account findByUsername(String username) {
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT uuid, username, password_hash, balance, is_admin FROM mybkn_accounts WHERE username = ?")) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Account(
                            UUID.fromString(rs.getString("uuid")),
                            rs.getString("username"),
                            rs.getString("password_hash"),
                            rs.getDouble("balance"),
                            rs.getBoolean("is_admin")
                    );
                }
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("[MybknCore] findByUsername hatasi: " + e.getMessage());
        }
        return null;
    }

    /** Directly sets balance in DB for a possibly-offline account. */
    public void setBalanceDirect(UUID uuid, double newBalance) {
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "UPDATE mybkn_accounts SET balance = ? WHERE uuid = ?")) {
            ps.setDouble(1, newBalance);
            ps.setString(2, uuid.toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            plugin.getLogger().severe("[MybknCore] setBalanceDirect hatasi: " + e.getMessage());
        }

        Account cached = cache.get(uuid);
        if (cached != null) {
            cached.setBalance(newBalance);
        }
    }
}
