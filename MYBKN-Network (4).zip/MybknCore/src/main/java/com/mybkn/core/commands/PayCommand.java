package com.mybkn.core.commands;

import com.mybkn.core.MybknCore;
import com.mybkn.core.data.Account;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.UUID;

public class PayCommand implements CommandExecutor {

    private final MybknCore plugin;

    public PayCommand(MybknCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Bu komut sadece oyun icinde kullanilabilir.");
            return true;
        }

        if (!plugin.getAccountManager().isLoggedIn(player.getUniqueId())) {
            player.sendMessage("§cOnce giris yapmalisin! §7/login <sifre>");
            return true;
        }

        if (args.length != 2) {
            player.sendMessage("§cKullanim: §e/pay <oyuncu> <miktar>");
            return true;
        }

        String targetName = args[0];
        double amount;
        try {
            amount = Double.parseDouble(args[1]);
        } catch (NumberFormatException e) {
            player.sendMessage("§cMiktar sayi olmali!");
            return true;
        }

        if (amount <= 0) {
            player.sendMessage("§cMiktar 0'dan buyuk olmali!");
            return true;
        }

        Account senderAcc = plugin.getAccountManager().getCached(player.getUniqueId());
        if (senderAcc == null) {
            player.sendMessage("§cBir hata olustu, hesabin yuklenemedi.");
            return true;
        }

        if (senderAcc.getBalance() < amount) {
            player.sendMessage("§cYetersiz bakiye! Bakiyen: §e" + senderAcc.getBalance()
                    + plugin.getConfig().getString("economy.para-birimi", "₺"));
            return true;
        }

        Player targetOnline = Bukkit.getPlayerExact(targetName);
        String currency = plugin.getConfig().getString("economy.para-birimi", "₺");

        if (targetOnline != null) {
            // both online: do it on main thread for safety, persist async
            UUID targetUuid = targetOnline.getUniqueId();
            if (!plugin.getAccountManager().isLoggedIn(targetUuid)) {
                player.sendMessage("§cBu oyuncu su anda giris yapmamis, para gonderemezsin.");
                return true;
            }

            Account targetAcc = plugin.getAccountManager().getCached(targetUuid);
            senderAcc.setBalance(senderAcc.getBalance() - amount);
            targetAcc.setBalance(targetAcc.getBalance() + amount);

            player.sendMessage("§a" + targetName + "§f'a §e" + amount + currency + "§f gonderdin.");
            targetOnline.sendMessage("§e" + player.getName() + "§f senden §a" + amount + currency + "§f aldi.");

            new BukkitRunnable() {
                @Override
                public void run() {
                    plugin.getAccountManager().saveBalance(player.getUniqueId());
                    plugin.getAccountManager().saveBalance(targetUuid);
                    plugin.getAccountManager().logTransaction(player.getUniqueId(), targetUuid, amount, "PAY", null);
                }
            }.runTaskAsynchronously(plugin);
            return true;
        }

        // target offline: do the whole thing async against the DB
        new BukkitRunnable() {
            @Override
            public void run() {
                Account offlineTarget = plugin.getAccountManager().findByUsername(targetName);
                if (offlineTarget == null) {
                    Bukkit.getScheduler().runTask(plugin, () ->
                            player.sendMessage("§cBoyle bir oyuncu bulunamadi."));
                    return;
                }

                senderAcc.setBalance(senderAcc.getBalance() - amount);
                plugin.getAccountManager().saveBalance(player.getUniqueId());
                plugin.getAccountManager().setBalanceDirect(
                        offlineTarget.getUuid(), offlineTarget.getBalance() + amount);
                plugin.getAccountManager().logTransaction(
                        player.getUniqueId(), offlineTarget.getUuid(), amount, "PAY", "offline");

                Bukkit.getScheduler().runTask(plugin, () ->
                        player.sendMessage("§a" + targetName + "§f'a §e" + amount + currency + "§f gonderdin."));
            }
        }.runTaskAsynchronously(plugin);

        return true;
    }
}
