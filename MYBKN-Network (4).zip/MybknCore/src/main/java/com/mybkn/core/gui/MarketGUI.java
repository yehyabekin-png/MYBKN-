package com.mybkn.core.gui;

import com.mybkn.core.MybknCore;
import com.mybkn.core.market.MarketItem;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple chest-GUI market. Left click buys 1, right click sells 1
 * (handled in MarketGUIListener). This keeps the GUI itself dumb -
 * it just renders items - and puts the actual logic in the listener.
 */
public class MarketGUI {

    public static final String TITLE = "§8MYBKN Market";

    public static Inventory build(MybknCore plugin) {
        List<MarketItem> marketItems = plugin.getMarketManager().getItems();
        int size = Math.max(9, ((marketItems.size() / 9) + 1) * 9);
        size = Math.min(size, 54);

        Inventory inv = Bukkit.createInventory(null, size, TITLE);

        for (MarketItem item : marketItems) {
            ItemStack stack = new ItemStack(item.getMaterial());
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.setDisplayName("§e" + item.getDisplayName());
                List<String> lore = new ArrayList<>();
                lore.add("§7Alis: §a" + item.getBuyPrice() + "₺ §7(sol tik)");
                lore.add("§7Satis: §c" + item.getSellPrice() + "₺ §7(sag tik)");
                lore.add("");
                lore.add("§8id: " + item.getId());
                meta.setLore(lore);
                stack.setItemMeta(meta);
            }
            inv.addItem(stack);
        }

        return inv;
    }

    public static String extractIdFromLore(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null || stack.getItemMeta().getLore() == null) return null;
        for (String line : stack.getItemMeta().getLore()) {
            if (line.startsWith("§8id: ")) {
                return line.substring("§8id: ".length());
            }
        }
        return null;
    }
}
