package com.mybkn.core.commands;

import com.mybkn.core.MybknCore;
import com.mybkn.core.data.Account;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BalCommand implements CommandExecutor {

    private final MybknCore plugin;

    public BalCommand(MybknCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Bu komut sadece oyun icinde kullanilabilir.");
            return true;
        }

        if (!plugin.getAccountManager().isLoggedIn(player.getUniqueId())) {
            player.sendMessage("§cOnce giris yapmalisin! §7/login <sifre>");
            return true;
        }

        String currency = plugin.getConfig().getString("economy.para-birimi", "₺");

        if (args.length == 0) {
            Account acc = plugin.getAccountManager().getCached(player.getUniqueId());
            player.sendMessage("§e§l[MYBKN] §fBakiyen: §a" + format(acc.getBalance()) + currency);
            return true;
        }

        // /bal <oyuncu> - check someone else's balance
        String targetName = args[0];
        Player targetOnline = Bukkit.getPlayerExact(targetName);
        if (targetOnline != null) {
            Account targetAcc = plugin.getAccountManager().getCached(targetOnline.getUniqueId());
            if (targetAcc != null) {
                player.sendMessage("§e" + targetName + "§f'nin bakiyesi: §a" + format(targetAcc.getBalance()) + currency);
                return true;
            }
        }

        Account offlineAcc = plugin.getAccountManager().findByUsername(targetName);
        if (offlineAcc == null) {
            player.sendMessage("§cBoyle bir oyuncu bulunamadi.");
        } else {
            player.sendMessage("§e" + targetName + "§f'nin bakiyesi: §a" + format(offlineAcc.getBalance()) + currency);
        }
        return true;
    }

    private String format(double value) {
        return String.format("%,.2f", value);
    }
}
