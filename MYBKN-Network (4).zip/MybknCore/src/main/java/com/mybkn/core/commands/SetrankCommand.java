package com.mybkn.core.commands;

import com.mybkn.core.MybknCore;
import com.mybkn.core.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /setrank <oyuncu> <rank>
 *
 * Admin-only. Used to grant any rank directly, but its real purpose is
 * the special ranks that /rankup can never reach: INSAN, GUCLU, YUCE,
 * YOUTUBER, KURUCU.
 *
 * KURUCU is hard-locked to the username "ekmeko" - no one else can ever
 * receive it, even an admin running this command, because the network
 * is meant to have exactly one founder account.
 */
public class SetrankCommand implements CommandExecutor {

    private static final String KURUCU_USERNAME = "ekmeko";

    private final MybknCore plugin;

    public SetrankCommand(MybknCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("mybkn.admin.setrank")) {
            sender.sendMessage("§cBu komutu kullanma yetkin yok.");
            return true;
        }

        if (args.length != 2) {
            sender.sendMessage("§cKullanim: §e/setrank <oyuncu> <rank>");
            sender.sendMessage("§7Ranklar: " + ranksList());
            return true;
        }

        String targetName = args[0];
        Rank rank = Rank.byName(args[1]);

        if (rank == null) {
            sender.sendMessage("§cGecersiz rank! Ranklar: " + ranksList());
            return true;
        }

        if (rank == Rank.KURUCU && !targetName.equalsIgnoreCase(KURUCU_USERNAME)) {
            sender.sendMessage("§cKurucu ranki sadece §f" + KURUCU_USERNAME + " §chesabina verilebilir!");
            return true;
        }

        Player targetOnline = Bukkit.getPlayerExact(targetName);

        if (targetOnline != null) {
            if (!plugin.getAccountManager().isLoggedIn(targetOnline.getUniqueId())) {
                sender.sendMessage("§cBu oyuncu su anda giris yapmamis.");
                return true;
            }
            applyRank(targetOnline.getUniqueId(), rank);
            sender.sendMessage("§a" + targetName + "§f'in ranki §a" + rank.getDisplayName() + " §fyapildi.");
            targetOnline.sendMessage("§6§l[RANK] §fBir admin sana §f" + rank.getDisplayName()
                    + " §franki verdi! Tebrikler!");
            return true;
        }

        // offline - look up uuid via Bukkit's offline player cache
        OfflinePlayer offline = Bukkit.getOfflinePlayer(targetName);
        if (offline.getUniqueId() == null) {
            sender.sendMessage("§cBoyle bir oyuncu bulunamadi.");
            return true;
        }

        applyRank(offline.getUniqueId(), rank);
        sender.sendMessage("§a" + targetName + "§f'in ranki §a" + rank.getDisplayName() + " §fyapildi. §7(cevrimdisi)");
        return true;
    }

    private void applyRank(java.util.UUID uuid, Rank rank) {
        var progress = plugin.getRankManager().getCached(uuid);
        if (progress != null) {
            progress.setCurrentRank(rank);
        }
        plugin.getRankManager().persistRank(uuid, rank);
    }

    private String ranksList() {
        StringBuilder sb = new StringBuilder();
        for (Rank rank : Rank.values()) {
            if (sb.length() > 0) sb.append("§7, ");
            sb.append("§f").append(rank.name());
        }
        return sb.toString();
    }
}
